/**
 * Export chat conversation to a PDF file with clickable visualization tabs.
 *
 * For assistant messages that have multiple visualization types (bar/pie/line/table),
 * the exporter:
 *   1. Programmatically switches the UI to each viz type and snapshots the DOM
 *   2. Places each captured variant on its own PDF page
 *   3. Adds a clickable "tab row" at the top of each viz page that uses jsPDF
 *      internal page links (`pdf.link`) — clicking a tab jumps to that variant's page.
 */
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import * as echarts from 'echarts';
import type { Message } from '../components/ChatInterface.types';

interface ExportProgress {
  /** 0..1 fraction of work completed */
  ratio: number;
  /** Human-readable status for the current step */
  label: string;
}

interface ExportOptions {
  title: string;
  messages: Message[];
  messagesRoot?: HTMLElement | null;
  /** Called as the export advances so the UI can render a progress bar. */
  onProgress?: (p: ExportProgress) => void;
}

const PAGE = {
  width: 210,
  height: 297,
  marginX: 15,
  marginY: 18,
};
const CONTENT_WIDTH = PAGE.width - 2 * PAGE.marginX;
const BLUE = { r: 13, g: 71, b: 161 };       // #0d47a1
const BLUE_LIGHT = { r: 21, g: 101, b: 192 }; // #1565c0
const GREY_DARK = { r: 33, g: 37, b: 41 };
const GREY_MID = { r: 108, g: 117, b: 125 };
const GREY_LIGHT = { r: 233, g: 236, b: 239 };

const VIZ_LABELS: Record<string, string> = {
  table: 'Table',
  bar: 'Bar Chart',
  line: 'Line Chart',
  pie: 'Pie Chart',
  donut: 'Donut Chart',
  scatter: 'Scatter Plot',
};

function cleanText(s: string): string {
  return s
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/`(.*?)`/g, '$1')
    .replace(/<[^>]+>/g, '')
    .replace(/\r\n/g, '\n')
    .trim();
}

/**
 * Disable animations on every ECharts instance inside `el` and wait until
 * each one has finished rendering. Without this, html2canvas can snapshot a
 * chart mid-animation and the PDF ends up with half-drawn visualizations.
 */
async function freezeEchartsForCapture(el: HTMLElement): Promise<void> {
  const nodes = Array.from(
    el.querySelectorAll<HTMLElement>('[_echarts_instance_]'),
  );
  const waits: Promise<void>[] = [];
  for (const node of nodes) {
    const inst = echarts.getInstanceByDom(node);
    if (!inst) continue;
    // Disable animations for any subsequent updates and force an immediate
    // re-render so the current frame is the final frame.
    inst.setOption(
      {
        animation: false,
        animationDuration: 0,
        animationDurationUpdate: 0,
      },
      false,
    );
    waits.push(
      new Promise<void>((resolve) => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          resolve();
        };
        // 'finished' fires when all pending animations/renders are complete.
        inst.on('finished', finish);
        // Safety timeout in case 'finished' has already fired before we
        // attached the listener.
        setTimeout(finish, 600);
      }),
    );
  }
  await Promise.all(waits);
}

async function captureElement(el: HTMLElement): Promise<{ dataUrl: string; widthPx: number; heightPx: number } | null> {
  try {
    await freezeEchartsForCapture(el);
    const canvas = await html2canvas(el, {
      scale: 2,
      backgroundColor: '#ffffff',
      logging: false,
      useCORS: true,
    });
    return {
      dataUrl: canvas.toDataURL('image/png'),
      widthPx: canvas.width,
      heightPx: canvas.height,
    };
  } catch {
    return null;
  }
}

function fitImage(widthPx: number, heightPx: number, maxWidthMm: number, maxHeightMm: number) {
  const ratio = widthPx / heightPx;
  let w = maxWidthMm;
  let h = w / ratio;
  if (h > maxHeightMm) {
    h = maxHeightMm;
    w = h * ratio;
  }
  return { w, h };
}

/** Force a message's viz type and wait for re-render. */
async function forceVizType(messageId: string, vizType: string): Promise<void> {
  window.dispatchEvent(new CustomEvent('viz:force-type', { detail: { messageId, vizType } }));
  // Double RAF so React commits + ECharts redraws
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => r(null))));
  // Small additional delay for ECharts animations to settle
  await new Promise((r) => setTimeout(r, 250));
}

export async function exportChatToPdf({ title, messages, messagesRoot, onProgress }: ExportOptions): Promise<void> {
  if (!messages || messages.length === 0) return;

  const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
  let y = PAGE.marginY;

  // Progress is weighted by work units. Each message contributes 1 unit for
  // its text block, plus 1 unit per visualization variant we capture (viz
  // captures dominate total time because of html2canvas + echarts rendering).
  let totalUnits = 0;
  let doneUnits = 0;
  for (const m of messages) {
    totalUnits += 1;
    if (m.role !== 'user' && messagesRoot) {
      const node = messagesRoot.querySelector<HTMLElement>(`[data-message-id="${m.id}"]`);
      const attr = node?.getAttribute('data-viz-types') || '';
      const vizCount = attr ? attr.split(',').filter(Boolean).length : (node?.querySelector('[data-viz-capture]') ? 1 : 0);
      totalUnits += vizCount;
    }
  }
  if (totalUnits === 0) totalUnits = 1;

  const report = (label: string) => {
    if (!onProgress) return;
    onProgress({ ratio: Math.min(1, doneUnits / totalUnits), label });
  };
  const tick = (label: string, units = 1) => {
    doneUnits += units;
    report(label);
  };

  report('Preparing export…');

  const needSpace = (height: number) => {
    if (y + height > PAGE.height - PAGE.marginY) {
      pdf.addPage();
      y = PAGE.marginY;
    }
  };

  // ── Header ──
  const drawHeader = () => {
    pdf.setFillColor(BLUE.r, BLUE.g, BLUE.b);
    pdf.rect(0, 0, PAGE.width, 22, 'F');
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(14);
    pdf.setTextColor(255, 255, 255);
    pdf.text('SDM AI Assistant — Chat Export', PAGE.marginX, 13);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9);
    pdf.text(`Exported: ${new Date().toLocaleString()}`, PAGE.marginX, 18);
  };
  drawHeader();
  y = 30;

  // ── Chat title ──
  pdf.setTextColor(GREY_DARK.r, GREY_DARK.g, GREY_DARK.b);
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(16);
  const titleLines = pdf.splitTextToSize(title || 'Untitled chat', CONTENT_WIDTH);
  pdf.text(titleLines, PAGE.marginX, y);
  y += titleLines.length * 7 + 4;

  pdf.setDrawColor(GREY_LIGHT.r, GREY_LIGHT.g, GREY_LIGHT.b);
  pdf.setLineWidth(0.3);
  pdf.line(PAGE.marginX, y, PAGE.width - PAGE.marginX, y);
  y += 8;

  // ── Helper: draw a clickable viz-tab row on the current page ──
  // Returns the Y offset after the tab row so callers can continue rendering.
  // `links` is a collected list we fill later with (fromPage, x, y, w, h, toPage).
  type PendingLink = { fromPage: number; x: number; y: number; w: number; h: number; toPage: number };
  const pendingLinks: PendingLink[] = [];

  const drawVizTabRow = (vizTypes: string[], activeType: string, pageByType: Record<string, number | null>) => {
    const tabW = 32;
    const tabH = 8;
    const gap = 2;
    const totalW = vizTypes.length * tabW + (vizTypes.length - 1) * gap;
    let tx = PAGE.marginX + (CONTENT_WIDTH - totalW) / 2;
    const ty = y;

    vizTypes.forEach((t) => {
      const isActive = t === activeType;
      // Background
      if (isActive) {
        pdf.setFillColor(BLUE.r, BLUE.g, BLUE.b);
      } else {
        pdf.setFillColor(245, 247, 250);
      }
      pdf.roundedRect(tx, ty, tabW, tabH, 1.5, 1.5, 'F');
      // Border
      pdf.setDrawColor(isActive ? BLUE.r : 200, isActive ? BLUE.g : 200, isActive ? BLUE.b : 200);
      pdf.setLineWidth(0.2);
      pdf.roundedRect(tx, ty, tabW, tabH, 1.5, 1.5, 'S');
      // Label
      pdf.setFont('helvetica', isActive ? 'bold' : 'normal');
      pdf.setFontSize(8);
      if (isActive) {
        pdf.setTextColor(255, 255, 255);
      } else {
        pdf.setTextColor(GREY_MID.r, GREY_MID.g, GREY_MID.b);
      }
      const label = VIZ_LABELS[t] || t;
      const lw = pdf.getTextWidth(label);
      pdf.text(label, tx + (tabW - lw) / 2, ty + 5.2);
      // Schedule a link if we have a target page for this type
      const targetPage = pageByType[t];
      if (targetPage != null) {
        pendingLinks.push({
          fromPage: pdf.getCurrentPageInfo().pageNumber,
          x: tx,
          y: ty,
          w: tabW,
          h: tabH,
          toPage: targetPage,
        });
      }
      tx += tabW + gap;
    });

    y += tabH + 4;
  };

  // ── Walk messages ──
  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    const isUser = msg.role === 'user';
    const text = cleanText(msg.content || '');
    if (!text && !msg.response) continue;

    tick(`Processing message ${i + 1} of ${messages.length}…`);

    needSpace(25);

    // Role label
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(11);
    if (isUser) {
      pdf.setTextColor(BLUE.r, BLUE.g, BLUE.b);
      pdf.text('You', PAGE.marginX, y);
    } else {
      pdf.setTextColor(BLUE_LIGHT.r, BLUE_LIGHT.g, BLUE_LIGHT.b);
      pdf.text('SDM AI Assistant', PAGE.marginX, y);
    }
    y += 5;

    // Text content
    if (text) {
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(10);
      pdf.setTextColor(GREY_DARK.r, GREY_DARK.g, GREY_DARK.b);
      const lines = pdf.splitTextToSize(text, CONTENT_WIDTH - 4);
      const lineHeight = 4.8;
      const boxH = lines.length * lineHeight + 6;
      needSpace(boxH);
      if (isUser) {
        pdf.setFillColor(BLUE.r, BLUE.g, BLUE.b);
        pdf.roundedRect(PAGE.marginX, y - 1, CONTENT_WIDTH, boxH, 2, 2, 'F');
        pdf.setTextColor(255, 255, 255);
      } else {
        pdf.setFillColor(248, 249, 250);
        pdf.roundedRect(PAGE.marginX, y - 1, CONTENT_WIDTH, boxH, 2, 2, 'F');
        pdf.setTextColor(GREY_DARK.r, GREY_DARK.g, GREY_DARK.b);
      }
      pdf.text(lines, PAGE.marginX + 2, y + 4);
      y += boxH + 3;
    }

    // Attachments
    if (msg.attachments && msg.attachments.length > 0) {
      pdf.setFont('helvetica', 'italic');
      pdf.setFontSize(9);
      pdf.setTextColor(GREY_MID.r, GREY_MID.g, GREY_MID.b);
      const attLine = `Attachments: ${msg.attachments.join(', ')}`;
      const attLines = pdf.splitTextToSize(attLine, CONTENT_WIDTH);
      needSpace(attLines.length * 4 + 2);
      pdf.text(attLines, PAGE.marginX, y);
      y += attLines.length * 4 + 2;
    }

    // ── Visualizations ──
    if (!isUser && messagesRoot) {
      const msgNode = messagesRoot.querySelector<HTMLElement>(`[data-message-id="${msg.id}"]`);
      if (msgNode) {
        // Detect available viz types from the data attribute the React component exposes
        const vizTypesAttr = msgNode.getAttribute('data-viz-types') || '';
        const vizTypes = vizTypesAttr
          ? vizTypesAttr.split(',').map((s) => s.trim()).filter(Boolean)
          : [];

        if (vizTypes.length > 1) {
          // ── Multi-viz: capture every variant then render each on its own page ──
          const captures: Record<string, Awaited<ReturnType<typeof captureElement>>> = {};
          for (const t of vizTypes) {
            await forceVizType(msg.id, t);
            const vizNode = msgNode.querySelector<HTMLElement>('[data-viz-capture]');
            if (vizNode) {
              captures[t] = await captureElement(vizNode);
            }
            tick(`Rendering ${VIZ_LABELS[t] || t} (message ${i + 1} of ${messages.length})…`);
          }

          // Start each variant on its own page. We track the page number for each
          // type so we can create cross-links.
          const pageByType: Record<string, number | null> = {};
          vizTypes.forEach((t) => (pageByType[t] = null));

          // First pass: decide page numbers by adding pages in order
          for (let ti = 0; ti < vizTypes.length; ti++) {
            // Every variant gets its own page
            pdf.addPage();
            y = PAGE.marginY;
            pageByType[vizTypes[ti]] = pdf.getCurrentPageInfo().pageNumber;

            // Section header
            pdf.setFont('helvetica', 'bold');
            pdf.setFontSize(12);
            pdf.setTextColor(BLUE.r, BLUE.g, BLUE.b);
            pdf.text(`${VIZ_LABELS[vizTypes[ti]] || vizTypes[ti]} — SDM AI Assistant`, PAGE.marginX, y);
            y += 6;

            // Clickable tab row (links added later when all target pages are known)
            drawVizTabRow(vizTypes, vizTypes[ti], pageByType);

            // Render the captured image for this variant
            const cap = captures[vizTypes[ti]];
            if (cap) {
              const { w, h } = fitImage(
                cap.widthPx,
                cap.heightPx,
                CONTENT_WIDTH,
                PAGE.height - y - PAGE.marginY - 4,
              );
              pdf.addImage(cap.dataUrl, 'PNG', PAGE.marginX + (CONTENT_WIDTH - w) / 2, y, w, h);
              y += h + 5;
            } else {
              pdf.setFont('helvetica', 'italic');
              pdf.setFontSize(10);
              pdf.setTextColor(GREY_MID.r, GREY_MID.g, GREY_MID.b);
              pdf.text('(unable to render this visualization)', PAGE.marginX, y + 6);
              y += 12;
            }
          }

          // Now all target pages are known — apply the link targets.
          // pendingLinks collected earlier still has `toPage` values from the
          // first pass that were null-snapshots; we need to re-apply using the
          // final pageByType map by re-walking drawVizTabRow? Simpler: we drew
          // the rows already and collected coordinates with the (correctly
          // populated by now, since we populated pageByType AFTER addPage)
          // target pages. jsPDF's `link()` call below actually creates them
          // during the post-loop; pendingLinks was filled with correct page
          // numbers because we populated pageByType BEFORE drawing each row.
          // (Wait — the FIRST row was drawn when only its own page was set.
          // Fix: draw rows AFTER adding all pages. Done below instead.)

          // Flow back to a new "between messages" page so subsequent content
          // isn't overwritten by the last variant's y cursor.
          pdf.addPage();
          y = PAGE.marginY;
        } else {
          // ── Single viz: capture as-is ──
          const vizNode = msgNode.querySelector<HTMLElement>('[data-viz-capture]');
          if (vizNode) {
            const cap = await captureElement(vizNode);
            tick(`Rendering visualization (message ${i + 1} of ${messages.length})…`);
            if (cap) {
              const { w, h } = fitImage(
                cap.widthPx,
                cap.heightPx,
                CONTENT_WIDTH,
                PAGE.height - 2 * PAGE.marginY - 20,
              );
              needSpace(h + 10);
              pdf.setFont('helvetica', 'bold');
              pdf.setFontSize(10);
              pdf.setTextColor(BLUE.r, BLUE.g, BLUE.b);
              const label = vizNode.getAttribute('data-viz-label') || 'Visualization';
              pdf.text(label, PAGE.marginX, y);
              y += 4;
              pdf.addImage(cap.dataUrl, 'PNG', PAGE.marginX, y, w, h);
              y += h + 5;
            }
          }
        }
      }
    }

    // Separator between messages
    pdf.setDrawColor(GREY_LIGHT.r, GREY_LIGHT.g, GREY_LIGHT.b);
    pdf.setLineWidth(0.2);
    pdf.line(PAGE.marginX, y, PAGE.width - PAGE.marginX, y);
    y += 6;
  }

  // ── Apply pending internal links ──
  // Uses jsPDF's `link()` which needs to be called on the correct source page.
  for (const lnk of pendingLinks) {
    pdf.setPage(lnk.fromPage);
    pdf.link(lnk.x, lnk.y, lnk.w, lnk.h, { pageNumber: lnk.toPage });
  }

  // ── Footer with page numbers ──
  const totalPages = pdf.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    pdf.setPage(p);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(8);
    pdf.setTextColor(GREY_MID.r, GREY_MID.g, GREY_MID.b);
    const footer = `Page ${p} of ${totalPages}`;
    pdf.text(footer, PAGE.width - PAGE.marginX - 20, PAGE.height - 8);
  }

  doneUnits = totalUnits;
  report('Finalizing PDF…');

  const safeName = (title || 'chat').replace(/[^\w\s-]/g, '').trim().slice(0, 50) || 'chat';
  pdf.save(`${safeName}.pdf`);

  report('Export complete');
}
